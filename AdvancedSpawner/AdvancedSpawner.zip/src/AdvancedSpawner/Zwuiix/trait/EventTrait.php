<?php

namespace AdvancedSpawner\Zwuiix\trait;

use AdvancedSpawner\Zwuiix\entity\MobEntity;
use AdvancedSpawner\Zwuiix\entity\MobStacker;
use AdvancedSpawner\Zwuiix\spawner\SpawnerHandler;
use AdvancedSpawner\Zwuiix\tile\MobSpawnerTile;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\EventPriority;
use pocketmine\item\ItemBlock;
use pocketmine\player\Player;
use pocketmine\scheduler\ClosureTask;
use ReflectionException;

trait EventTrait
{
    /**
     * @throws ReflectionException
     */
    public function loadEvents(): void
    {
        $this->getServer()->getPluginManager()->registerEvent(BlockPlaceEvent::class, function (BlockPlaceEvent $event) {
            $block = $event->getBlockAgainst();
            $item = $event->getItem();

            if($event->isCancelled()) {
                return;
            }

            if(!$item instanceof ItemBlock) {
                return;
            }
            $tx = $event->getTransaction();
            foreach (SpawnerHandler::getInstance()->getAll() as $spawner) {
                if($spawner->getBlock()->equals($item, false, false)) {
                    foreach($tx->getBlocks() as [$x, $y, $z, $b]){
                        \AdvancedSpawner::getInstance()->getScheduler()->scheduleDelayedTask(new ClosureTask(function () use($block, $b, $spawner) {
                            $block->getPosition()->getWorld()->addTile(($tile = new MobSpawnerTile($block->getPosition()->getWorld(), $b->getPosition())));
                            $tile->setSpawnerType($spawner);
                        }), 20);
                    }
                    break;
                }
            }
        }, EventPriority::LOWEST, $this);
        $this->getServer()->getPluginManager()->registerEvent(BlockBreakEvent::class, function (BlockBreakEvent $event) {
            $block = $event->getBlock();
            $tile = $block->getPosition()->getWorld()->getTile($block->getPosition());

            if($event->isCancelled()) {
                return;
            }

            if($tile instanceof MobSpawnerTile) {
                $tile->close();
            }
        }, EventPriority::LOWEST, $this);

        $this->getServer()->getPluginManager()->registerEvent(EntityDamageEvent::class, function (EntityDamageEvent $event) {
            $entity = $event->getEntity();
            if (!$entity instanceof MobEntity) return;

            $mobStacker = new Mobstacker($entity);
            if ($entity->getHealth() - $event->getFinalDamage() <= 0) {
                $cause = null;
                if($event instanceof EntityDamageByEntityEvent) {
                    $player = $event->getDamager();
                    if($player instanceof Player) $cause = $player;
                }
                if ($mobStacker->removeStack($cause)) $event->cancel();
            }
        }, EventPriority::LOWEST, $this);
    }
}