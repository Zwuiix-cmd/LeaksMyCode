# InventoryUIResourcePack
Resource pack for [InventoryUI](https://github.com/tedo0627/InventoryUI)
